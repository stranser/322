﻿using System;
using System.Drawing.Imaging;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.EntityFrameworkCore;
using Utilitiescore.Models;

namespace Utilitiescore
{
    public partial class RegisterForm : Window
    {
        private readonly AppDbContext _context;
        private string _captchaCode;

        public RegisterForm()
        {
            InitializeComponent();
            _context = new AppDbContext();
            GenerateCaptcha();
        }

        private void GenerateCaptcha()
        {
            // Создаем случайный код
            _captchaCode = GenerateCaptchaCode();

            // Генерируем изображение
            var captchaImage = GenerateCaptchaImage(_captchaCode);

            // Отображаем капчу в интерфейсе
            CaptchaImage.Source = BitmapFrame.Create(captchaImage);
        }

        private string GenerateCaptchaCode()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            return new string(Enumerable.Repeat(chars, 6).Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private MemoryStream GenerateCaptchaImage(string captchaCode)
        {
            const int width = 150;
            const int height = 50;

            var bitmap = new Bitmap(width, height);
            var random = new Random();

            using (var graphics = Graphics.FromImage(bitmap))
            {
                graphics.Clear(Color.White);

                // Добавляем случайные линии для сложности
                for (int i = 0; i < 10; i++)
                {
                    var pen = new Pen(Color.FromArgb(random.Next(256), random.Next(256), random.Next(256)));
                    graphics.DrawLine(pen, random.Next(width), random.Next(height), random.Next(width), random.Next(height));
                }

                // Рисуем текст капчи
                using (var font = new Font("Arial", 20))
                {
                    var brush = new SolidBrush(Color.FromArgb(random.Next(256), random.Next(256), random.Next(256)));
                    graphics.DrawString(captchaCode, font, brush, 10, 10);
                }
            }

            var memoryStream = new MemoryStream();
            bitmap.Save(memoryStream, ImageFormat.Png);
            memoryStream.Position = 0;

            return memoryStream;
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        private async void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new AppDbContext()) // Новый контекст для операции
            {
                var username = UsernameTextBox.Text.Trim();
                var password = PasswordBox.Password;
                var captchaInput = CaptchaTextBox.Text.Trim();

                // Проверка капчи
                if (captchaInput != _captchaCode)
                {
                    MessageBox.Show("Код с изображения введен неверно!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    GenerateCaptcha();
                    return;
                }

                // Проверка, что логин уже существует в базе данных
                var existingUser = await context.Users

                    .Where(u => u.Логин == username)
                    .FirstOrDefaultAsync();

                if (existingUser != null)
                {
                    MessageBox.Show("Пользователь с таким логином уже существует.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Хэшируем пароль
                var passwordHash = HashPassword(password);

                // Создаем нового пользователя
                var newUser = new Сотдрудник
                {
                    Логин = username,
                    Пароль = passwordHash
                };

                // Добавляем пользователя в базу данных
                context.Users.Add(newUser);
                await context.SaveChangesAsync();

                MessageBox.Show("Регистрация успешна!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                var registerWindow = new LoginForm();
                registerWindow.Show();
                Hide();
            }

          
        }  private void RefreshCaptchaButton_Click(object sender, RoutedEventArgs e)
            {
                GenerateCaptcha();
            }
    } }
