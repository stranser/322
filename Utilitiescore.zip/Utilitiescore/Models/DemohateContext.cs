﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Utilitiescore.Models;

public partial class DemohateContext : DbContext
{
    public DemohateContext()
    {
    }

    public DemohateContext(DbContextOptions<DemohateContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Блюдо> Блюдоs { get; set; }

    public virtual DbSet<Должности> Должностиs { get; set; }

    public virtual DbSet<Заказ> Заказs { get; set; }

    public virtual DbSet<Ингридиент> Ингридиентs { get; set; }

    public virtual DbSet<Категории> Категорииs { get; set; }

    public virtual DbSet<Составблюда> Составблюдаs { get; set; }

    public virtual DbSet<Составзаказа> Составзаказаs { get; set; }

    public virtual DbSet<Сотдрудник> Сотдрудникs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=HIKIDEMON;Database=demohate;Trust Server Certificate=True; Integrated Security=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Блюдо>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Блюдо");

            entity.Property(e => e.Id).HasMaxLength(255);
            entity.Property(e => e.ВесОбъем)
                .HasMaxLength(255)
                .HasColumnName("Вес/Объем");
            entity.Property(e => e.ДоступноДляЗаказа)
                .HasMaxLength(255)
                .HasColumnName("Доступно для заказа");
            entity.Property(e => e.Категория).HasMaxLength(255);
            entity.Property(e => e.Название).HasMaxLength(255);
            entity.Property(e => e.СтоимостьРуб)
                .HasColumnType("money")
                .HasColumnName("Стоимость, руб");
        });

        modelBuilder.Entity<Должности>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Должности");

            entity.Property(e => e.Id).HasMaxLength(255);
            entity.Property(e => e.Название).HasMaxLength(255);
        });

        modelBuilder.Entity<Заказ>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Заказ");

            entity.Property(e => e.Id).HasMaxLength(255);
            entity.Property(e => e.Официант).HasMaxLength(255);
            entity.Property(e => e.Стол).HasMaxLength(255);
        });

        modelBuilder.Entity<Ингридиент>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Ингридиент");

            entity.Property(e => e.Id).HasMaxLength(255);
            entity.Property(e => e.КолВоНаСкладеГМл)
                .HasMaxLength(255)
                .HasColumnName("Кол-во на складе, г/мл");
            entity.Property(e => e.Название).HasMaxLength(255);
        });

        modelBuilder.Entity<Категории>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Категории");

            entity.Property(e => e.Id).HasMaxLength(255);
            entity.Property(e => e.Название).HasMaxLength(255);
        });

        modelBuilder.Entity<Составблюда>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Составблюда");

            entity.Property(e => e.Блюдо).HasMaxLength(255);
            entity.Property(e => e.Состав).HasMaxLength(255);
        });

        modelBuilder.Entity<Составзаказа>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Составзаказа");

            entity.Property(e => e.Id).HasMaxLength(255);
            entity.Property(e => e.Блюдо).HasMaxLength(255);
            entity.Property(e => e.Заказ).HasMaxLength(255);
            entity.Property(e => e.Количество).HasMaxLength(255);
            entity.Property(e => e.Статус).HasMaxLength(255);
        });

        modelBuilder.Entity<Сотдрудник>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Сотдрудник");

            entity.Property(e => e.Должность).HasMaxLength(255);
            entity.Property(e => e.Имя).HasMaxLength(255);
            entity.Property(e => e.Логин).HasMaxLength(255);
            entity.Property(e => e.Оклад).HasMaxLength(255);
            entity.Property(e => e.Отчество).HasMaxLength(255);
            entity.Property(e => e.Пароль).HasMaxLength(255);
            entity.Property(e => e.Фамилия).HasMaxLength(255);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
