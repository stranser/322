﻿using System;
using System.Collections.Generic;

namespace Utilitiescore.Models;

public partial class Заказ
{
    public string? Id { get; set; }

    public string? Официант { get; set; }

    public string? Стол { get; set; }
}
