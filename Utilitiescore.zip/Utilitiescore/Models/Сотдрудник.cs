﻿using System;
using System.Collections.Generic;

namespace Utilitiescore.Models;

public partial class Сотдрудник
{
     public string Логин { get; set; } = null!;
    public string? Фамилия { get; set; }

    public string? Имя { get; set; }

    public string? Отчество { get; set; }

    public string? Должность { get; set; }

    public string? Оклад { get; set; }

    public string? Пароль { get; set; }
}
