﻿using System;
using System.Collections.Generic;

namespace Utilitiescore.Models;

public partial class Блюдо
{
    public string? Id { get; set; }

    public string? Название { get; set; }

    public string? ВесОбъем { get; set; }

    public string? Категория { get; set; }

    public decimal? СтоимостьРуб { get; set; }

    public string? ДоступноДляЗаказа { get; set; }
}
