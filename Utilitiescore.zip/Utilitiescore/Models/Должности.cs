﻿using System;
using System.Collections.Generic;

namespace Utilitiescore.Models;

public partial class Должности
{
    public string? Id { get; set; }

    public string? Название { get; set; }
}
