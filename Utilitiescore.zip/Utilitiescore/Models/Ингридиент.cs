﻿using System;
using System.Collections.Generic;

namespace Utilitiescore.Models;

public partial class Ингридиент
{
    public string? Id { get; set; }

    public string? Название { get; set; }

    public string? КолВоНаСкладеГМл { get; set; }
}
