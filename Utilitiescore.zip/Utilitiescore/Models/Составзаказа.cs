﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Utilitiescore.Models;

public partial class Составзаказа
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public string Id { get; set; } = null!;

    public string? Заказ { get; set; }

    public string? Блюдо { get; set; }

    public string? Количество { get; set; }

    public string? Статус { get; set; }
}
