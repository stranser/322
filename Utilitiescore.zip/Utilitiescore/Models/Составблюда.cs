﻿using System;
using System.Collections.Generic;

namespace Utilitiescore.Models;

public partial class Составблюда
{
    public string? Блюдо { get; set; }

    public string? Состав { get; set; }
}
