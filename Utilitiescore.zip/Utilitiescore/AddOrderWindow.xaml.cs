﻿using System.Windows;
using System.Windows.Controls;
using Utilitiescore.Models;

namespace Utilitiescore
{
    public partial class AddOrderWindow : Window
    {
        private readonly AppDbContext _context;

        public AddOrderWindow()
        {
            InitializeComponent();
            _context = new AppDbContext();
        }

        private async void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Создаем новый заказ
                var order = new Составзаказа
                {
                    Заказ = TitleTextBox.Text.Trim(),
                    Блюдо = DescriptionTextBox.Text.Trim(),
                    Количество = PriceTextBox.Text.Trim()
                };

                // Добавляем заказ в базу данных
                _context.Составзаказаs.Add(order);
                await _context.SaveChangesAsync();

                MessageBox.Show("Заказ успешно добавлен.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                DialogResult = true; // Закрыть окно с успехом
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false; // Отменить операцию
            Close();
        }
    }
}
