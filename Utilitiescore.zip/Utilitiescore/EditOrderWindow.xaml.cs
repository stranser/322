﻿using System.Windows;
using System.Windows.Controls;
using Utilitiescore.Models;

namespace Utilitiescore
{
    public partial class EditOrderWindow : Window
    {
        private readonly AppDbContext _context;
        private readonly Составзаказа _order;

        public EditOrderWindow(Составзаказа order)
        {
            InitializeComponent();
            _context = new AppDbContext();
            _order = order;

            // Инициализируем поля текущими значениями заказа
            TitleTextBox.Text = _order.Заказ;
            DescriptionTextBox.Text = _order.Блюдо;
            PriceTextBox.Text = _order.Количество.ToString();
        }

        private async void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Обновляем данные заказа
                _order.Заказ = TitleTextBox.Text.Trim();
                _order.Блюдо = DescriptionTextBox.Text.Trim();
                _order.Количество = PriceTextBox.Text.Trim();

                // Сохраняем изменения в базе данных
                _context.Составзаказаs.Update(_order);
                await _context.SaveChangesAsync();

                MessageBox.Show("Изменения успешно сохранены.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                DialogResult = true; // Закрыть окно с успехом
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false; // Отменить операцию
            Close();
        }
    }
}
