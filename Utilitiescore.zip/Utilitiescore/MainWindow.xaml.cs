﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;
using Utilitiescore.Models;

namespace Utilitiescore
{
    public partial class MainWindow : Window
    {
        private readonly AppDbContext _context;

        public MainWindow()
        {
            InitializeComponent();
            _context = new AppDbContext();

            // Загрузка данных из базы данных
            LoadOrders();
        }

        private async void LoadOrders()
        {
            try
            {
                // Загружаем данные заказов из базы данных
                var orders = await _context.Составзаказаs.ToListAsync();
                OrdersDataGrid.ItemsSource = orders;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddOrderButton_Click(object sender, RoutedEventArgs e)
        {
            // Открытие окна добавления заказа
            var addOrderWindow = new AddOrderWindow();
            if (addOrderWindow.ShowDialog() == true)
            {
                // Перезагрузка данных после добавления
                LoadOrders();
            }
        }

        private void EditOrderButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, что заказ выбран
            var selectedOrder = OrdersDataGrid.SelectedItem as Составзаказа;
            if (selectedOrder == null)
            {
                MessageBox.Show("Пожалуйста, выберите заказ для редактирования.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Открытие окна редактирования заказа
            var editOrderWindow = new EditOrderWindow(selectedOrder);
            if (editOrderWindow.ShowDialog() == true)
            {
                // Перезагрузка данных после редактирования
                LoadOrders();
            }
        }

        private async void DeleteOrderButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, что заказ выбран
            var selectedOrder = OrdersDataGrid.SelectedItem as Составзаказа;
            if (selectedOrder == null)
            {
                MessageBox.Show("Пожалуйста, выберите заказ для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Подтверждение удаления
            if (MessageBox.Show($"Вы уверены, что хотите удалить заказ {selectedOrder.Id}?",
                                "Подтверждение",
                                MessageBoxButton.YesNo,
                                MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    // Удаляем заказ из базы данных
                    _context.Составзаказаs.Remove(selectedOrder);
                    await _context.SaveChangesAsync();

                    MessageBox.Show("Заказ успешно удалён.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                    // Перезагрузка данных после удаления
                    LoadOrders();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления заказа: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var registerWindow = new LoginForm();
            registerWindow.Show();
            Hide();
        }
    }
}
