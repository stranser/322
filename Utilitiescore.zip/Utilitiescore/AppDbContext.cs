﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitiescore.Models;

namespace Utilitiescore
{
    public class AppDbContext : DbContext
    {
       

        public virtual DbSet<Блюдо> Блюдоs { get; set; }

        public virtual DbSet<Должности> Должностиs { get; set; }

        public virtual DbSet<Заказ> Заказs { get; set; }

        public virtual DbSet<Ингридиент> Ингридиентs { get; set; }

        public virtual DbSet<Категории> Категорииs { get; set; }

        public virtual DbSet<Составблюда> Составблюдаs { get; set; }

        public virtual DbSet<Составзаказа> Составзаказаs { get; set; }

        public virtual DbSet<Сотдрудник> Users { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=HIKIDEMON;Database=demohate;Trust Server Certificate=True; Integrated Security=True;");
            //Scaffold-DbContext "Server=HIKIDEMON;Database=demohate;Trust Server Certificate=True; Integrated Security=True;" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models -Context AppDbContext 
        }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Блюдо>(entity =>
            {
                entity
                    .HasNoKey()
                    .ToTable("Блюдо");

                entity.Property(e => e.Id).HasMaxLength(255);
                entity.Property(e => e.ВесОбъем)
                    .HasMaxLength(255)
                    .HasColumnName("Вес/Объем");
                entity.Property(e => e.ДоступноДляЗаказа)
                    .HasMaxLength(255)
                    .HasColumnName("Доступно для заказа");
                entity.Property(e => e.Категория).HasMaxLength(255);
                entity.Property(e => e.Название).HasMaxLength(255);
                entity.Property(e => e.СтоимостьРуб)
                    .HasColumnType("money")
                    .HasColumnName("Стоимость, руб");
            });

            modelBuilder.Entity<Должности>(entity =>
            {
                entity
                    .HasNoKey()
                    .ToTable("Должности");

                entity.Property(e => e.Id).HasMaxLength(255);
                entity.Property(e => e.Название).HasMaxLength(255);
            });

            modelBuilder.Entity<Заказ>(entity =>
            {
                entity
                    .HasNoKey()
                    .ToTable("Заказ");

                entity.Property(e => e.Id).HasMaxLength(255);
                entity.Property(e => e.Официант).HasMaxLength(255);
                entity.Property(e => e.Стол).HasMaxLength(255);
            });

            modelBuilder.Entity<Ингридиент>(entity =>
            {
                entity
                    .HasNoKey()
                    .ToTable("Ингридиент");

                entity.Property(e => e.Id).HasMaxLength(255);
                entity.Property(e => e.КолВоНаСкладеГМл)
                    .HasMaxLength(255)
                    .HasColumnName("Кол-во на складе, г/мл");
                entity.Property(e => e.Название).HasMaxLength(255);
            });

            modelBuilder.Entity<Категории>(entity =>
            {
                entity
                    .HasNoKey()
                    .ToTable("Категории");

                entity.Property(e => e.Id).HasMaxLength(255);
                entity.Property(e => e.Название).HasMaxLength(255);
            });

            modelBuilder.Entity<Составблюда>(entity =>
            {
                entity
                    .HasNoKey()
                    .ToTable("Составблюда");

                entity.Property(e => e.Блюдо).HasMaxLength(255);
                entity.Property(e => e.Состав).HasMaxLength(255);
            });

            modelBuilder.Entity<Составзаказа>(entity =>
            {

                entity.HasKey(e => e.Id);
                   entity .ToTable("Составзаказа");

                entity.Property(e => e.Id).HasMaxLength(255);
                entity.Property(e => e.Блюдо).HasMaxLength(255);
                entity.Property(e => e.Заказ).HasMaxLength(255);
                entity.Property(e => e.Количество).HasMaxLength(255);
                entity.Property(e => e.Статус).HasMaxLength(255);
            });

            modelBuilder.Entity<Сотдрудник>(entity =>
            {
                entity.HasKey(e => e.Логин); // Установка первичного ключа

                entity.ToTable("Сотдрудник"); // Название таблицы в базе данных

                // Дополнительные настройки, если нужно
                entity.Property(e => e.Логин).IsRequired();
                entity.Property(e => e.Фамилия).HasMaxLength(50);
                entity.Property(e => e.Имя).HasMaxLength(50);
                entity.Property(e => e.Отчество).HasMaxLength(50);
                entity.Property(e => e.Должность).HasMaxLength(50);
                entity.Property(e => e.Оклад).HasMaxLength(20);
                entity.Property(e => e.Пароль).HasMaxLength(256);
            });


        }

    }
   
}
